package com.cg.cap.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cap.bean.Cap;
import com.cg.cap.exception.CapException;
import com.cg.cap.service.CapService;



//@CrossOrigin(origins="http://localhost:4040")
@RestController
public class CapController 
{
@Autowired
CapService Service;


@RequestMapping(value="/add", method=RequestMethod.POST)
public void addproduct(@RequestBody Cap b) {
	Service.addProduct(b);
}

@GetMapping(value="/set/{id}")
public void setStatus(@PathVariable int id) 
{
	Service.setStatus(id);	 
}

@RequestMapping(value="/get/{id}" ,method=RequestMethod.GET)
public String getStatus(@PathVariable int id) 
{
	return Service.getStatus(id);	 
}
}
