package com.cg.cap.bean;




import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//import org.springframework.format.annotation.dateOfOrdnoOfDaysForDeliveryFormat;

@Entity
public class Cap 
{
@Id
private int product_Id;
//@dateOfOrdnoOfDaysForDeliveryFormat(pattern="dd/MM/yyyy")
private String dateOfOrd;
private int noOfDaysForDelivery;
private String status;

public int getProduct_Id() {
	return product_Id;
}
public void setProduct_Id(int product_Id) {
	this.product_Id = product_Id;
}

public int getnoOfDaysForDelivery() {
	return noOfDaysForDelivery;
}
public void setnoOfDaysForDelivery(int noOfDaysForDelivery) {
	this.noOfDaysForDelivery = noOfDaysForDelivery;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getdateOfOrd() {
	return dateOfOrd;
}
public void setdateOfOrd(String dateOfOrd) {
	this.dateOfOrd = dateOfOrd;
}


}
