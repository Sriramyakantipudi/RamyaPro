package com.cg.cap.service;

import com.cg.cap.bean.Cap;

public interface CapService 
{	
	public void addProduct(Cap b);
	public void setStatus(int product_id);
	public String getStatus(int product_id);	
}
